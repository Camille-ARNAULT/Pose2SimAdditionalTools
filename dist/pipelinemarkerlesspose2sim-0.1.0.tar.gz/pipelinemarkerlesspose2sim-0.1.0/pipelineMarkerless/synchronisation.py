import os

os.system('python -m skelly_synchronize')

