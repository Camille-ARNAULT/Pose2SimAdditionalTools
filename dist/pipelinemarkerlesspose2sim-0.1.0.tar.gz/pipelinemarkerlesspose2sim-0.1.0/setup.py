from setuptools import setup

setup(
    name='pipelineMarkerlessPose2Sim',
    version='0.1.0',    
    description='pipeline to personalise Pose2Sim',
    url='https://github.com/Camille-ARNAULT/pipelineMarkerless',
    author='Stephen Hudson',
    author_email='camille.arnault@univ-poitiers.fr',
    license='no licence',
    packages=['pipelineMarkerless'],
    install_requires=['mpi4py>=3.0',
                      'numpy',                     
                      ],

    classifiers=[
        'Development Status :: 1 - Testing',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: BSD License',  
        'Operating System :: POSIX :: Linux',        
        'Programming Language :: Python :: 3.9'
    ],
)